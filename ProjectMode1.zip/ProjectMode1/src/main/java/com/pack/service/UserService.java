package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.UserDao;
import com.pack.model.User;

public class UserService {
	@Autowired
	private UserDao userDAO;
 public void loginCheck(User user)
 {
	 UserDAO.validate(user);
 }

	public void addCustomer(Customer customer,Account account) {
		  userDAO.addCustomer(customer,account);  
		
	}
	

	

}
