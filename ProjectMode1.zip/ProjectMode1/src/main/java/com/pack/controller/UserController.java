package com.pack.controller;
import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.model.User;
import com.pack.service.UserService;
@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@RequestMapping("login")
	public String getlogin(Model m)
	{
		
		m.addAttribute("userBean", new User());
		return "login";
	}
	
	
	@RequestMapping(value="loginCheck", method = RequestMethod.POST)
	public String saveUser(@Valid @ModelAttribute("userBean")User user,BindingResult result,Model m)
	{
		 if (result.hasErrors())
			 {
                return  "login";
			 }
		 else
		 {
			 return "Homepage";
		 }

}
	@RequestMapping("createCustomer")
	public String addCustomer(Model m)
	{
		m.addAttribute("cust",new Customer());
		return "Customer";
	}
	@RequestMapping(value="addCustomer",method=RequestMethod.POST)
	public String addCustomer(@valid@ModelAttribute("cust")Customer c,BindingResult result,Model m)
{
	if(result.hasErrors())
	{
		return "Customer";
	}
	else
	{
		return "final";
	}
}

