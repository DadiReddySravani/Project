package com.pack.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.pack.model.User;

public class UserDao {

@Autowired
private	 SessionFactory sessionFactory;


public String loginCheck(User user)
{
	System.out.println("In Check login");
	Session session = sessionFactory.openSession();
	String hql =" from Users as o where o.username=username and o.password=password";
	Query query = session.createQuery(hql);
	query.setParameter("username",user.getUsername());
	query.setParameter("password",user.getPassword());
	List list = query.list();

	if ((list != null) && (list.size() > 0)) {
		return "success";
	}
	else
	{
		return "failed";
	}
public String addCustomer(Customer customer,Account account)
{
	System.out.println("AddCustomer");
	Random r=new Random();
	Session session = sessionFactory.openSession();
	Transcation tx=session.beginTransaction();
	long num=(long)r.nextInt(1000000);
	Long account=(long)r.nextInt(10000);
	String accountno="33245623456"+account.toString();
	customer.setId(num);
	account.setCustId(customer);
	account.setAccountNo(Long.parseLong(accountno));
	account.setAccountType(accountType);
	long i=(long) session.save(account);
return i;
}
	           
}

}
