package com.pack.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Account")

public class Account {
@Id
@Column(name="accountno")
private long accountno;

public long getAccountno() {
	return accountno;
}

public void setAccountno(long accountno) {
	this.accountno = accountno;
}
@Column(name="accounttype")
private String accounttype;

public String getAccounttype() {
	return accounttype;
}

public void setAccounttype(String accounttype) {
	this.accounttype = accounttype;
}
@ManyToOne(cascade=CascadeType.ALL)
@JoinColumn(name="custId",unique=true)
private Customer custId;

public Customer getCustId() {
	return custId;
}

public void setCustId(Customer custId) {
	this.custId = custId;
}


}
